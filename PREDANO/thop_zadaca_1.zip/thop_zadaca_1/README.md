# thop_zadaca_1
NWTiS
